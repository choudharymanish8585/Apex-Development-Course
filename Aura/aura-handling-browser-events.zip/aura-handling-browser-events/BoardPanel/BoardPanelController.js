({
    startGame: function (component, event, helper) {
        console.log("The start new game button is clicked");
    },

    reshuffleBoard: function (component, event, helper) {
        console.log("Reshuffle board is called");
    }
});
